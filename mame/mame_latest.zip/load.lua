emu.keypost("b")
emu.keypost("    \n")
emu.keypost("load\n")
